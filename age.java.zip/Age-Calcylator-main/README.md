# code Alpha Internship

Description:

This is a simple web-based Age Calculator created using JavaScript. It calculates users' ages based on their submitted date of birth, month, and year. The age calculation process is simplified using JavaScript's built-in date and time functions.

How to Use:

Clone the repository to your local machine.
Open the index.html file in your web browser.
Input your date of birth, month, and year in the provided fields.
Click the "Calculate Age" button.
Your age will be displayed below the button.

Technologies Used:

HTML
CSS
JavaScript
